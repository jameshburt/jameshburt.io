function UATSpaceTrans(){
    location.replace("UATSpace.html");

}
function objScripts(){
    location.replace("objectives.html");

 }

 