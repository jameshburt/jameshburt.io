function UATSpaceTrans(){
    location.replace("UATSpace.html");

}

function indexTrans(){
    location.replace("index.html");

 }